﻿namespace congestion_tax_calculator_net_core.BO
{
    public class TaxRate
    {
        public string starttime { get; set; }
        public string endtime { get; set; }
        public int rate { get; set; }
    }
}
